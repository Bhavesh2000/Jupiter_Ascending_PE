import React from "react";
import axios from "axios";
class Dashboard extends React.Component{
  
  constructor(props){
    super(props);

    this.state={
      coursemodel:[]
    };
  }
  
  componentDidMount() {
    axios.get(`url${1}`).then(
      result=>{
        this.setState({coursemodel:result});
      }
    )

  }
  render() {
    return (
      <div>
        <p>Welcome to the Dashboard Page!</p>
        <h2>Course model</h2>
        <table>
          <thead>
            <tr>
              <th>id</th>
              <th>course name</th>
            </tr>
          </thead>
          <tbody>
            {this.state.coursemodel.map(course=>(
              <tr key={course.id}>
                <td>{course.id}</td>
                <td>{course.coursename}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    );
  }
}

export default Dashboard;
